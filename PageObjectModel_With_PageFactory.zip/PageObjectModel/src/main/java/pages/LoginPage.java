package pages;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;

		PageFactory.initElements(driver, this);

	}

	@CacheLookup
//	@FindBy(how=How.ID, using="username") WebElement uName;
	// AND Condition
	/*
	 * @FindBys({ @FindBy(how = How.NAME, using = "username"),
	 * 
	 * @FindBy(how = How.XPATH, using = "//input[@id='username']") }
	 * 
	 * )
	 */
	// OR condition
	@FindAll({ @FindBy(how = How.NAME, using = "username"),
			@FindBy(how = How.XPATH, using = "//input") }

	)
	List<WebElement> uName;

	// actionFieldname
	public LoginPage enterUsername(String username) throws InterruptedException {
		// driver.findElementById("username").sendKeys(username);
		uName.get(0).sendKeys(username);
		
	//	uName.sendKeys(username);

		// Thread.sleep(5000);
		return this;
	}

	@CacheLookup
	@FindBy(how = How.ID, using = "password")
	WebElement pWord;

	public LoginPage enterPassword(String password) {
		// driver.findElementById("password").sendKeys(password);
		pWord.sendKeys(password);
		return this;
	}

	/*
	 * @CacheLookup
	 * 
	 * @FindBy(how = How.CLASS_NAME, using = "decorativeSubmit") WebElement login;
	 */

	public HomePage clickLoginButton() {

		 driver.findElementByClassName("decorativeSubmit").click();
		//login.click();
		return new HomePage(driver);
	}

	public LoginPage clickLoginButtonForNegative() {
		 driver.findElementByClassName("decorativeSubmit").click();
	//	login.click();
		return this;
	}

}
