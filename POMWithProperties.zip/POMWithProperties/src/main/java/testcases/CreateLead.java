package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void setFile() {
		excelFileName = "CreateLead";

	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String username, String password, String company, String firstName, String lastName) throws InterruptedException {
		new LoginPage(driver,prop)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.enterCompanyName(company)
		.clicCreateLeadButton()
		.verifyFirstName();

	}

}
