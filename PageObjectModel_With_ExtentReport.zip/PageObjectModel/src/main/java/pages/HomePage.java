package pages;

import java.io.IOException;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	public LoginPage clickLogoutButton() {
		
		driver.findElementByClassName("decorativeSubmit").click();
		
		return new LoginPage(driver);
		
	}
	
	public MyHomePage clickCrmsfa() {
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage(driver);

	}
	
	
	public HomePage verifyHomePageIsDisplayed() throws IOException {
		try {
			reportStep("HomePage is displayed", "pass");
		} catch (Exception e) {
			reportStep("HomePage not displayed", "fail");
		}
		return this;
	}
	
	
	
	
	
	

}
