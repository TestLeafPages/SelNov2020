package pages;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.FindBys;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

import base.ProjectSpecificMethods;

public class LoginPage extends ProjectSpecificMethods {

	public LoginPage(ChromeDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}


	// actionFieldname
	public LoginPage enterUsername(String username) throws IOException  {
		try {
			driver.findElementById("username123").sendKeys(username);
			reportStep("username "+username+" entered successfully","pass");
		} catch (Exception e) {
			reportStep("username "+username+" not entered successfully","fail");
		}
		return this;
	}

	

	public LoginPage enterPassword(String password) throws IOException {
		try {
			driver.findElementById("password").sendKeys(password);
			reportStep("password entered successfully","pass");
		} catch (Exception e) {
			reportStep("password not entered successfully","fail");
		}
		
		return this;
	}

	

	public HomePage clickLoginButton() throws IOException {

		 try {
			driver.findElementByClassName("decorativeSubmit").click();
			reportStep("login button clicked", "pass");
		} catch (Exception e) {
			reportStep("login button not clicked", "fail");
		}
		 return new HomePage(driver);
	}

	public LoginPage clickLoginButtonForNegative() {
		 driver.findElementByClassName("decorativeSubmit").click();
		return this;
	}

}
