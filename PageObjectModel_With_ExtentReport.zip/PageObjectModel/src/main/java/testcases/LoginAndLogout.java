package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class LoginAndLogout extends ProjectSpecificMethods {
	
	@BeforeTest
	public void provideTestDetails() {
		testName = "LoginAndLogout";
		testDesc = "Login with positive credentials";
		testAuthor = "Hari";
		testCategory = "Smoke";
		excelFileName = "Login";

	}

	@Test(dataProvider = "fetchData")
	public void loginTest(String username, String password) throws InterruptedException, IOException {

		// LoginPage lp = new LoginPage();

		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.verifyHomePageIsDisplayed();
		//.clickLogoutButton();

	}

}
