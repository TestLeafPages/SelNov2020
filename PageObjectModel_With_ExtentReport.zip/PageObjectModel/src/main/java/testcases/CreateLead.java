package testcases;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.ProjectSpecificMethods;
import pages.LoginPage;

public class CreateLead extends ProjectSpecificMethods{
	
	@BeforeTest
	public void provideTestDetails() {
		testName = "CreateLead";
		testDesc = "Create Lead with mandatory fields";
		testAuthor = "Hari";
		testCategory = "Regression";
		excelFileName = "CreateLead";

	}
	
	@Test(dataProvider = "fetchData")
	public void runCreateLead(String username, String password, String company, String firstName, String lastName) throws InterruptedException {
		new LoginPage(driver)
		.enterUsername(username)
		.enterPassword(password)
		.clickLoginButton()
		.clickCrmsfa()
		.clickLeads()
		.clickCreateLead()
		.enterFirstName(firstName)
		.enterLastName(lastName)
		.enterCompanyName(company)
		.clicCreateLeadButton()
		.verifyFirstName();

	}

}
