package pages;

import org.openqa.selenium.chrome.ChromeDriver;

import base.ProjectSpecificMethods;

public class HomePage extends ProjectSpecificMethods{
	public HomePage(ChromeDriver driver) {
		this.driver = driver;
		
	}
	public LoginPage clickLogoutButton() {
		
		driver.findElementByClassName("decorativeSubmit").click();
		
		return new LoginPage(driver);
		
	}
	
	public MyHomePage clickCrmsfa() {
		driver.findElementByLinkText("CRM/SFA").click();
		return new MyHomePage(driver);

	}
	
	
	public HomePage verifyHomePageIsDisplayed() {
		System.out.println("Home Page is dispalyed");
		return this;
	}
	
	
	
	
	
	

}
