package steps;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LearnHooks extends BaseClass{
	
	
	
	@Before
	public void beforeScenario(Scenario sc) {
		WebDriverManager.chromedriver().setup();
		//System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
			
		System.out.println("Name: "+sc.getName());
		System.out.println("URI: "+sc.getUri());
		System.out.println("Line number: "+ sc.getLine());
		
	}
	
	@After
	public void afterScenario(Scenario sc) {
		driver.close();
		System.out.println("Status: "+ sc.getStatus());
		
	}

}
