package runner;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;

@CucumberOptions(features = "src/test/java/features/", 
glue = "steps", monochrome = true, publish = true, 
//tags = "@functional" //to run only functional
//tags = "@smoke or @functional" // to execute all the scenarios with @smoke or @functional
//tags = "@regression and @functional" // to execute the testcases contain both @functional and @regression
tags = "not @functional" //to execute all the testcases except @functional
)

public class RunTest extends AbstractTestNGCucumberTests {

}
