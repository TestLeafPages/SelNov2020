package steps;

import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class LoginSteps {
	
	public ChromeDriver driver;
	
	@Given("Open the chrome browser")
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}
	
	@Given("Maximize the browser")
	public void maxBrowser() {
		driver.manage().window().maximize();
	}
	
	@Given("Load the leaftaps application URL")
	public void loadURL() {
		driver.get("http://leaftaps.com/opentaps/control/main");
	}
	
	@Given("Enter username in the Login page as {string}")
	public void enterUserName(String uName) {
		driver.findElementById("username").sendKeys(uName);
	}
	
	@Given("Enter password in the Login page as {string}")
	public void enterPassword(String pwd) {
		driver.findElementById("password").sendKeys(pwd);
	}
	
	@When("Click in the Login button")
	public void clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}
	
	@Then("Verify Login is success")
	public void verifyLogin() {
		System.out.println("Login is Success");
	}

}
