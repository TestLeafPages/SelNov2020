package steps;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;

public class LearnHooks {
	
	@Before
	public void beforeScenario(Scenario sc) {
		System.out.println("Name: "+sc.getName());
		System.out.println("URI: "+sc.getUri());
		System.out.println("Line number: "+ sc.getLine());
	}
	
	@After
	public void afterScenario(Scenario sc) {
		System.out.println("Status: "+ sc.getStatus());
	}

}
